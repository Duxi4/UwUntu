/* This is a generated file; DO NOT EDIT */
/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Accordion")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Agnes")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Athena")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Auld Lang Syne")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Aunt Mary")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Backbone")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Bakers Dozen")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Bakers Game")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Bear River")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Beleaguered Castle")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Block Ten")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Bristol")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Camelot")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Canfield")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Carpet")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Chessboard")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Clock")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Cover")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Cruel")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Diamond Mine")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Doublets")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Eagle Wing")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Easthaven")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Eight Off")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Elevator")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Eliminator")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Escalator")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("First Law")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Fortress")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Fortunes")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Forty Thieves")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Fourteen")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Freecell")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Gaps")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Gay Gordons")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Giant")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Glenwood")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Gold Mine")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Golf")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Gypsy")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Hamilton")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Helsinki")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Hopscotch")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Isabel")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Jamestown")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Jumbo")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Kansas")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("King Albert")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Kings Audience")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Klondike")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Labyrinth")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Lady Jane")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Maze")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Monte Carlo")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Napoleons Tomb")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Neighbor")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Odessa")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Osmosis")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Peek")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Pileon")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Plait")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Poker")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Quatorze")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Royal East")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Saratoga")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Scorpion")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Scuffle")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Seahaven")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Sir Tommy")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Sol")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Spider")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Spider Three Decks")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Spiderette")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Straight Up")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Streets And Alleys")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Template")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Ten Across")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Terrace")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Thieves")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Thirteen")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Thumb And Pouch")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Treize")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Triple Peaks")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Union Square")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Valentine")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Wall")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Westhaven")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Whitehead")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Will O The Wisp")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Yield")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Yukon")

/* Translators: this string is the name of a game of patience.
 If there is an established standard name for this game in your
 locale, use that; otherwise you can translate this string
 freely, literally, or not at all, at your option.
 */
N_("Zebra")

