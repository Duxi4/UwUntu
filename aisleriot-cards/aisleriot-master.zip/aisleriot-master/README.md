# Aisleriot

Aisleriot — also known as sol or solitaire — is a card game
application that features over 80 different solitaire-type card
games which are designed to play using a mouse, keyboard, or trackpad.

## Useful links

- Homepage: <https://wiki.gnome.org/Apps/Aisleriot>
- Report issues: <https://gitlab.gnome.org/GNOME/aisleriot/issues>
- Translate: <https://wiki.gnome.org/TranslationProject>
